#include <stdio.h>

#define MIN_SIZE 1
#define MAX_SIZE 100


unsigned read_size();
unsigned read_rotations();
void fill_array(int arr[100], unsigned size);
void rotate_array(int arr[100], unsigned size, unsigned rot);
void print_array(int arr[100], unsigned size);



int main(void) {

    const unsigned size = read_size();
    int array[MAX_SIZE];
    fill_array(array, size);
    unsigned rotations = read_rotations();

    rotate_array(array, size, rotations);

    puts("Rotated array:");
    print_array(array, size);

    return 0;
}



unsigned read_size() {
    int res;
    unsigned size;
    do {
        printf("Input size of array ( from 1 to 100 ): ");
        res = scanf("%d", &size);
        if (res != 1) {
            while (getchar() != '\n') {}
        }
    }while(res != 1 || (size < MIN_SIZE || size > MAX_SIZE));
    return size;
}


unsigned read_rotations() {
    int res;
    unsigned rot;
    do {
        printf("Input rotations of array (rotation is movement of all elements to the left by one position): ");
        res = scanf("%d", &rot);
        if (res != 1) {
            while (getchar() != '\n') {}
        }
    }while(res != 1);
    return rot;
}


void fill_array(int arr[], const unsigned size) {
    int res;
    for (int i = 0; i < size; i++) {
        do {
            printf("Input value for elem %d: ", i+1);
            res = scanf("%d", &arr[i]);
            if (res != 1) {
                while (getchar() != '\n') {}
            }
        }while (res != 1);
    }
}


void rotate_array(int arr[], const unsigned size, unsigned rot) {

    if(!(rot %= size)) {
        return;
    }

    int tmp_arr[MAX_SIZE];

    for (unsigned i = 0; i < rot; i++) {
        tmp_arr[i] = arr[i];
    }

    for (unsigned i = rot; i < size; i++) {
        arr[i-rot] = arr[i];
    }

    for (unsigned i = size-rot; i < size; i++) {
        arr[i] = tmp_arr[i-(size-rot)];
    }
}


void print_array(int arr[100], unsigned size) {
    for (int i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
}